using System;

namespace csharptest
{
    class Result
    {
        static void Main(string[] args)
        {
            //////////////////////////
            Random rand = new Random();
            Separation a;
            Separation b;
            a = Separation.Parse("-3,7");
            b = Separation.Parse("23/-11");
            Separation[] massive = new Separation[10];
            //////////////////////////

            Console.WriteLine("a = " + a + " = " + a.ToString('f') + " = " + a.ToString('F') + " = " + a.ToString('d') + " = " + a.ToString('D'));
            Console.WriteLine("b = " + b + " = " + (double)b + " = " + (long)b + " = " + (float)b + " = " + (decimal)b);
            
            Console.WriteLine("");
            
            if (a > b)
            {
                Console.WriteLine("a > b");
            }
            if (a < b)
            {
                Console.WriteLine("a < b");
            }
            if (a == b)
            {
                Console.WriteLine("a == b");
            }
            if (a != b)
            {
                Console.WriteLine("a != b");
            }
            if (a <= b)
            {
                Console.WriteLine("a <= b");
            }
            if (a >= b)
            {
                Console.WriteLine("a >= b");
            }
            
            Console.WriteLine("\na + b = " + a + " + " + b + " = " + (a + b) + " = " + (a + b).ToString('d'));
            Console.WriteLine("a - b = " + a + " - " + b + " = " + (a - b) + " = " + (a - b).ToString('f'));
            
            Console.WriteLine("\na * b = " + a + " * " + b + " = " + (a * b) + " = " + (a * b).ToString('d'));
            Console.WriteLine("a / b = " + a + " / " + b + " = " + (a / b) + " = " + (a / b).ToString('D'));

            //сортировка
            Console.WriteLine("\nБез сортировки:");
            for (int i = 0; i< 10; i++)
            {
                massive[i] = new Separation(rand.Next(-50, 100), rand.Next(-50, 100));
                Console.Write(massive[i] + " ");
            }
            Array.Sort(massive);
            Console.WriteLine("\nС сортировкой:");
            for (int i = 0; i < 10; i++)
            {
                Console.Write(massive[i] + " ");
            }

        }
    }
}